# 프로그램 감시 + 키보드 감시
import os,signal
import keyboard
import time
from threading import Thread
from tkinter import messagebox
import sys
from sys import platform




